clc;
clear;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Task1: Generating and matrix
and_matrix=[];
sensor_names=["ALX","ALY","ALZ","ARX","ARY","ARZ","EMG0L","EMG1L","EMG2L","EMG3L","EMG4L","EMG5L","EMG6L","EMG7L","EMG0R","EMG1R","EMG2R","EMG3R","EMG4R","EMG5R","EMG6R","EMG7R","GLX","GLY","GLZ","GRX","GRY","GRZ","ORL","OPL","OYL","ORR","OPR","OYR"];

column_first=[];
files = dir('*.csv');
m=1;
for file = files'
    csv = readtable(file.name,'ReadRowNames',false);
    new_var1=csv(:,1:34);
    if size(new_var1,1)>55
        continue
    end
    if size(new_var1,1)<35
        continue
    end
    old_matrix=table2array(new_var1);
    size_old=size(old_matrix);
    if size_old(:,1)<55
        var1=[old_matrix; zeros((55-size_old(:,1)),34)];
    else
        var1=old_matrix;
    end
    and_matrix=[and_matrix;var1'];
    for k=1:34
       s=" ";
       column1=strcat("ACTION",s,num2str(m),s,sensor_names(k)); 
       column_first=[column_first;column1];
    end
end


final_matrix=[];
final_matrix=horzcat(column_first,and_matrix);
final_table=array2table(final_matrix);
%writetable(final_table,'and.csv','WriteRowNames',false);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Task 2: Extracting features
sorted_by_feature=[];
for feature=1:34
for i=1:size(and_matrix,1)
    if mod(i,34)==feature
        sorted_by_feature=[sorted_by_feature; and_matrix(i,:)];
    end
    
end
end
for i=1:size(and_matrix,1)
    if mod(i,34)==0
        sorted_by_feature=[sorted_by_feature; and_matrix(i,:)];
    end
end

%For accelerometer
feature_number=[1,2,3,4,5,6];
feature_extracted=[];
feature_acc=[];
for i=1:size(feature_number,2)
    factor=size(and_matrix,1)/34;
    feature_extracted=sorted_by_feature((feature_number(:,i)-1)*factor+1:(feature_number(:,i))*factor,:)
    %mean_feature=mean(feature_extracted,2);
    rms_feature = sqrt(mean(feature_extracted.^2,2))/size(feature_extracted,1);
    var_feature=var(feature_extracted,0,2);
    ZCR=mean(abs(diff(sign(feature_extracted))),2);
    %mean_abs_dev_feature=mad(feature_extracted,0,2);
    %integration_feature=trapz(feature_extracted,2);
    %signal_magnitude_area=sum(feature_extracted,2);
    %eps=0.000001;
    %Entropy_feature = -sum(A.*log(A+eps));
    %Entropy_feature=Entropy_feature';
      
    feature_acc=horzcat(feature_acc,rms_feature,var_feature,[ZCR;0]);
end

%For gyroscope: Standard deviation, RMS, ZCR and ABSDIFF
feature_number=[23,24,25,26,27,28];
feature_extracted=[];
feature_gyr=[];
for i=1:size(feature_number,2)
    factor=size(and_matrix,1)/34;
    feature_extracted=sorted_by_feature((feature_number(:,i)-1)*factor+1:(feature_number(:,i))*factor,:)
    %rms_feature = sqrt(mean(feature_extracted.^2,2))/size(feature_extracted,1);
    var_feature=var(feature_extracted,0,2);
    %ZCR=mean(abs(diff(sign(feature_extracted))),2);
    mean_abs_dev_feature=mad(feature_extracted,0,2);
    %integration_feature=trapz(feature_extracted,2);
    %signal_magnitude_area=sum(feature_extracted,2);
    %eps=0.000001;
    %Entropy_feature = -sum(A.*log(A+eps));
    %Entropy_feature=Entropy_feature';
      
    feature_gyr=horzcat(feature_gyr,var_feature,mean_abs_dev_feature);
end

%For EMG: RMS, Integrated EMG(IEMG) ,Mean Absolute Value (MAV) ,Variance, Zero Crossing
feature_number=[7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22];
feature_extracted=[];
feature_emg=[];
for i=1:size(feature_number,2)
    factor=size(and_matrix,1)/34;
    feature_extracted=sorted_by_feature((feature_number(:,i)-1)*factor+1:(feature_number(:,i))*factor,:); 
    mav_feature=mean(abs(feature_extracted),2);
    %rms_feature = sqrt(mean(feature_extracted.^2,2))/size(feature_extracted,1);
    %var_feature=var(feature_extracted,0,2);
    ZCR=mean(abs(diff(sign(feature_extracted))),2);
      
    feature_emg=horzcat(feature_emg,mav_feature,[ZCR;0]);
end

%For OR 29,30,31,32,33,34 :First 5-FFT coefficients,Spectral energy,Standard deviation
%ZCR,Zero-crossing rate,Absolute difference
feature_number=[29,30,31,32,33,34];
feature_extracted=[];
feature_or=[];
for i=1:size(feature_number,2)
    factor=size(and_matrix,1)/34;
    feature_extracted=sorted_by_feature((feature_number(:,i)-1)*factor+1:(feature_number(:,i))*factor,:); 
    fft_feature=fft(feature_extracted);
    %rms_feature = sqrt(mean(feature_extracted.^2,2))/size(feature_extracted,1);
    %std_feature=std(feature_extracted,0,2);
    %ZCR=mean(abs(diff(sign(feature_extracted))),2);
    energy = sum(abs(fft_feature).^2,2); 
    feature_or=horzcat(feature_or,[ZCR;0],energy);
end

feature_matrix=horzcat(feature_acc,feature_gyr,feature_emg,feature_or);
%csvwrite('features_and.csv',feature_matrix,0,0);

%Plotting graphs for features
%  for i=1:size(feature_matrix,2)
% figure(i);
% histogram(feature_matrix(:,i),16);
% title(strcat('and feature ', num2str(i)));
% xlabel('Feature values');
% ylabel('Frequency');
%  end
 
%  for i=1:size(feature_or,2)
% figure(i);
% histogram(feature_or(:,i),16);
% title(strcat('and feature ', num2str(i)));
% xlabel('Feature values');
% ylabel('Frequency');
%  end
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Task 3: Finding PCA on and feature matrix
[coeff,score,latent] = pca(feature_matrix);
N=1:size(feature_matrix,2);
legendCell = cellstr(num2str(N', 'N=%-d'))
biplot(coeff(:,1:2),'Scores',score(:,1:2),'Varlabels',legendCell);
title("and- Eigenvector 1 and 2 Biplot");
title(strcat('and feature ', num2str(i)));
xlabel('Feature values');
ylabel('Frequency');
projection=feature_matrix*coeff;
pca_matrix=projection(:,1:7);
csvwrite('PCA_and.csv',pca_matrix,0,0);
%Plotting graphs of first 10 eigenvectors
% for i=1:10
%     figure(i+76);
%     histogram(projection(:,i),16);
%     title(strcat("PCA feature "+num2str(i)));
%     xlabel('Projected values');
%     ylabel('Frequency');
% end
